package Pages;

public interface ReceiptScanner {
	public String getTextFromReceiptImage(final String receiptImageFilePath);
}
