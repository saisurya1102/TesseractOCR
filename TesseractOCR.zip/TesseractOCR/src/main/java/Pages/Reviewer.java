package Pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author 123
 */
public class Reviewer extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
        	HttpSession session = request.getSession();
            String[] user = (String[]) session.getAttribute("user");
            if(user==null)
        	{
        		response.sendRedirect("index.jsp");
        	}
            else {
            String n = user[0];
            String org = user[1];
            String type = user[2];
            String id = user[3];
            String admin = user[4];
        	out.println("<!DOCTYPE html>"
        			+ "<html>"
        			+ "  "
        			+ "<head>"
        			+ "	<meta charset=\"UTF-8\">"
        			+ "	"
        			+ "	<style> "
        			+ "	"
        			+ "	:root {"
        			+ "	  	--orange1 : #f4511e;"
        			+ "	  	--violet1: #d279d2;"
        			+ "	  	--violet2: #732673;"
        			+ "	  	--greyBlue: #29293d;"
        			+ "		--orange2 : #8c0803;"
        			+ "		--blue1 : #95a8ac;"
        			+ "		--blue2 : #223745;"
        			+ "		--white : #ecebe2;"
        			+ "		--grey : #a8a194;"
        			+ "		--beige : #e0d2b4;"
        			+ "		--beigePink : #e4c9b4;"
        			+ "		--pink : #d0a292;"
        			+ "		--brown : #9b785e;"
        			+ "	}"
        			+ "	"
        			+ "	html, body {"
        			+ "    max-width: 100%;"
        			+ "    overflow-x: hidden;"
        			+ "    margin:0;"
        			+ "	}"
        			+ "		.header"
        			+ "		{"
        			+ "		    height: 250px;"
        			+ "		    width: 90%;"
        			+ "		    transform: translate(-50%, 0);"
        			+ "		    left:50%;"
        			+ "		    position: absolute;"
        			+ "		    background-color:var(--white);"
        			+ "		    border-radius:25px;"
        			+ "		    margin-left:20px;"
        			+ "		    margin-top:70px;"
        			+ "		    margin-right:10px;"
        			+ "		}"
        			+ "		.test"
        			+ "		{"
        			+ "		    height: 100%;"
        			+ "			width: 65px;"
        			+ "			z-index:9999;"
        			+ "			position: fixed;"
        			+ "			background-color: var(--blue2);"
        			+ "			top: 0;"
        			+ "			left: 0;"
        			+ "			overflow-x: hidden;"
        			+ "			transition: 0.5s;"
        			+ "			padding-top: 100px;"
        			+ "		}"
        			+ "		"
        			+ "		.test a"
        			+ "		{"
        			+ "		 	padding-left:50px;"
        			+ "		 	padding-top:30px;"
        			+ "		 	padding-bottom:30px;"
        			+ "			line-height: 1.42857143 !important;"
        			+ "			letter-spacing: 4px;"
        			+ "			text-decoration: none;"
        			+ "			font-size: 20px;"
        			+ "			z-index: 9999;"
        			+ "			font-weight: bold;"
        			+ "			text-transform: uppercase;"
        			+ "			position: relative;"
        			+ "			color: white;"
        			+ "			display: block;"
        			+ "			transition: 0.3s;"
        			+ "		}"
        			+ "		.qsub{"
        			+ "		  background-color: var(--orange1);"
        			+ "		  padding: 10px;"
        			+ "		  width: 170px;"
        			+ "		  color:white;"
        			+ "		  border: none;  "
        			+ "	      text-decoration:none;"
        			+ "		}"
        			+ "		.test a:hover"
        			+ "		{"
        			+ "			text-decoration: none;"
        			+ "			font-size: 20px;"
        			+ "			position: relative;"
        			+ "			color: white;"
        			+ "			display: block;"
        			+ "			transition: 0.3s;"
        			+ "			background-color: grey;"
        			+ "		}"
        			+ "		"
        			+ "		.hi"
        			+ "		{"
        			+ "		    position:absolute;"
        			+ "			transform: translate(0, -50%);"
        			+ "		    top:60%;"
        			+ "			font-size: 56px;"
        			+ "			color: var(--blue2);"
        			+ "			padding-left:100px;"
        			+ "		}"
        			+ "		.menu"
        			+ "		{"
        			+ "			font-family: Montserrat, sans-serif;"
        			+ "			text-orientation: upright; "
        			+ "			writing-mode: vertical-rl;"
        			+ "			color: white;"
        			+ "			font-size:36px;"
        			+ "			position:absolute;"
        			+ "			transform: translate(0, -50%);"
        			+ "		    top:50%;"
        			+ "		}"
        			+ "		.item1"
        			+ "		{"
        			+ "			font-family: Montserrat, sans-serif;"
        			+ "			background-color: var(--blue2);"
        			+ "  		    z-index: 9999;"
        			+ "			font-size:30px;"
        			+ "			position: fixed;"
        			+ "			width: 100%;"
        			+ "		}"
        			+ "		.item1"
        			+ "		{"
        			+ "			font-family: Montserrat, sans-serif;"
        			+ "			background-color: var(--blue2);"
        			+ "  		    z-index: 9999;"
        			+ "			font-size:30px;"
        			+ "			position: fixed;"
        			+ "			width: 100%;"
        			+ "		}"
        			+ "		.item1 a"
        			+ "		{"
        			+ "			float: right;"
        			+ "			color:white;"
        			+ "			background-color: var(--blue2);"
        			+ "			text-align: center;"
        			+ "			padding: 16px 16px;"
        			+ "			line-height: 1.42857143 !important;"
        			+ "			letter-spacing: 4px;"
        			+ "			text-decoration: none;"
        			+ "			font-size: 16px;"
        			+ "			z-index: 9999;"
        			+ "			font-weight: 120;"
        			+ "		}"
        			+ "		.item1 a:hover {"
        			+ "			  background-color: var(--white);"
        			+ "			  color: black;"
        			+ "			  z-index: 9999;"
        			+ "			}"
        			+ "	</style>"
        			+ "</head>"
        			+ "  "
        			+ "<body>"
        			+ "	<div class=\"item1\">"
        			+ "		  <a href=\"#\" href='Logout'>LOGOUT</a>"
        			+ "		  <a class=\"active\" href=\"PaperSetter\">HOME</a>"
        			+ "			<img src=\"test.png\" width=\"50px;\" height=\"50px;\" style=\"position:absolute; left:200px; top:0px;\"><div style=\"color:white; position:absolute; left:80px; top:10px;\">DigiTest</div>"
        			+ "	</div>"
        			+ "	<div class=\"test\" id=\"demo\" onmouseover=\"slide()\" onmouseout=\"hide()\">"
        			+ "		<table>"
        			+ "			<tr>"
        			+ "			<td><img src=\"plus-sign.png\" width=40px; height=40px; style=\"margin-left:10px;\"></td><td><a href=\"insertInto\">Create</a></td>"
        			+ "			</tr>"
        			+ "			<tr>"
        			+ "			<td><img src=\"edit-list.png\" width=40px; height=40px; style=\"margin-left:10px;\"></td><td><a href=\"#\">Edit</a></td>"
        			+ "			</tr>"
        			+ "			<tr>"
        			+ "			<td><img src=\"setting.png\" width=40px; height=40px; style=\"margin-left:10px;\"></td><td><a href=\"#\">Settings</a></td>"
        			+ "			</tr>"
        			+ "			<tr>"
        			+ "			<td><img src=\"power-off.png\" width=40px; height=40px; style=\"margin-left:10px;\"></td><td><a href=\"Logout\">Logout</a></td>"
        			+ "			</tr>"
        			+ "		</table>"
        			+ "	</div>"
        			+ "	<div class=\"papers\"></div>"
        			+ "	<div class=\"header\"><div class=\"hi\">Hi, "+ n + "</div><img src=\"user1.png\" style=\"position:absolute; right:0;\"></div>");
        	
        	Class.forName("com.mysql.jdbc.Driver");		
        	Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/tesseractocr", "root", "");
            Statement stmt = connection.createStatement();
            String sql ="select * from questionpaper";
            ResultSet rs = stmt.executeQuery(sql);
            out.println("<table style='margin-left:300px; margin-top:450px; width:800px; padding:10px;'>");
            out.println("<tr style='background-color:var(--blue2); height:40px; color:\"white\"; font-size:\"22px\"; '><th style=\"width:70%\">Topic</th><th>Status</th><th>Action</th></tr>");
            while(rs.next())
            {
             	
            	if(rs.getInt("Reviewer")==Integer.parseInt(id))
            	{
            		if(rs.getString("Status").equals("Reviewed"))
            		{
            			out.println("<tr style='height:50px; padding-top:20px; padding-bottom:20px; border-bottom: 5px solid red; background-color:#b3e6cc;'><td style='padding-left:10px;'>" + rs.getString("Qname") + "</td><td style='text-align:center'>"+ rs.getString("Status") + "</td><td style='text-align:center'><a href='createVar?tablename="+ rs.getString("tablename") + "&review=" +  rs.getString("Status") + "' class='qsub'>" + "VIEW" + "</a></td></tr>");	
            		}
            		else
            		{
            			
            			out.println("<tr style='height:50px; padding-top:20px; padding-bottom:20px; border-bottom: 5px solid red;'><td style='padding-left:10px;'>" + rs.getString("Qname") + "</td><td style='text-align:center'>"+ rs.getString("Status") + "</td><td style='text-align:center'><a href='createVar?tablename="+ rs.getString("tablename") + "&review=" +  rs.getString("Status") + "' class='qsub'>" + "VIEW" + "</a></td></tr>");
            		}
            	}
            }
        	out.println( "</table></body>"
        			+ "  <script>"
        			+ "      function slide()"
        			+ "      {"
        			+ "    	  document.getElementById(\"demo\").style.width = \"250px\";"
        			+ "    	  document.getElementById(\"menu\").style.color = \"var(--blue2)\";"
        			+ "      }"
        		    + "      "
        			+ "      function hide()"
        			+ "      {"
        			+ "    	  document.getElementById(\"demo\").style.width = \"65px\";"
        			+ "    	  document.getElementById(\"menu\").style.color = \"white\";"
        			+ "      }"
        			+ " </script> "
        			+ "</html>");
            }
        }
        catch(Exception e)
        {
        	System.out.println(e);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
