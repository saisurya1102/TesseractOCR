package Pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author 123
 */
public class Test extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
        	HttpSession session = request.getSession();
        	String t = (String) session.getAttribute("tname");
            String[] user = (String[]) session.getAttribute("user");
            if(user==null)
        	{
        		response.sendRedirect("index.jsp");
        	}
            else {
            String n = user[0];
            String org = user[1];
            String type = user[2];
            String admin = user[4];
            Class.forName("com.mysql.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/tesseractocr", "root", "");
            Statement stmt = connection.createStatement();
            String sql ="select * from " + t;
            ResultSet rs = stmt.executeQuery(sql);
            
        	out.println("<!DOCTYPE html>"
        			+ "<html>"
        			+ "  "
        			+ "<head>"
        			+ "	<meta charset=\"UTF-8\">"
        			+ "	"
        			+ "	<style> "
        			+ "	"
        			+ "	:root {"
        			+ "	  	--orange1 : #f4511e;"
        			+ "	  	--violet1: #d279d2;"
        			+ "	  	--violet2: #732673;"
        			+ "	  	--greyBlue: #29293d;"
        			+ "		--orange2 : #8c0803;"
        			+ "		--blue1 : #95a8ac;"
        			+ "		--blue2 : #223745;"
        			+ "		--white : #ecebe2;"
        			+ "		--grey : #a8a194;"
        			+ "		--beige : #e0d2b4;"
        			+ "		--beigePink : #e4c9b4;"
        			+ "		--pink : #d0a292;"
        			+ "		--brown : #9b785e;"
        			+ "	}"
        			+ "	"
        			+ "	html, body {"
        			+ "    max-width: 100%;"
        			+ "    overflow-x: hidden;"
        			+ "    margin:0;"
        			+ "	}"
        			+ "		.header"
        			+ "		{"
        			+ "		    height: 250px;"
        			+ "		    width: 90%;"
        			+ "		    transform: translate(-50%, 0);"
        			+ "		    left:50%;"
        			+ "		    position: absolute;"
        			+ "		    background-color:var(--white);"
        			+ "		    border-radius:25px;"
        			+ "		    margin-left:20px;"
        			+ "		    margin-top:70px;"
        			+ "		    margin-right:10px;"
        			+ "		}"
        			+ "		.test"
        			+ "		{"
        			+ "		    height: 100%;"
        			+ "			width: 65px;"
        			+ "			z-index:9999;"
        			+ "			position: fixed;"
        			+ "			background-color: var(--blue2);"
        			+ "			top: 0;"
        			+ "			left: 0;"
        			+ "			overflow-x: hidden;"
        			+ "			transition: 0.5s;"
        			+ "			padding-top: 100px;"
        			+ "		}"
        			+ "		"
        			+ "		.test a"
        			+ "		{"
        			+ "		 	padding-left:50px;"
        			+ "		 	padding-top:30px;"
        			+ "		 	padding-bottom:30px;"
        			+ "			line-height: 1.42857143 !important;"
        			+ "			letter-spacing: 4px;"
        			+ "			text-decoration: none;"
        			+ "			font-size: 20px;"
        			+ "			z-index: 9999;"
        			+ "			font-weight: bold;"
        			+ "			text-transform: uppercase;"
        			+ "			position: relative;"
        			+ "			color: white;"
        			+ "			display: block;"
        			+ "			transition: 0.3s;"
        			+ "		}"
        			+ "		"
        			+ "		.test a:hover"
        			+ "		{"
        			+ "			text-decoration: none;"
        			+ "			font-size: 20px;"
        			+ "			position: relative;"
        			+ "			color: white;"
        			+ "			display: block;"
        			+ "			transition: 0.3s;"
        			+ "			background-color: grey;"
        			+ "		}"
        			+ "		"
        			+ "		.hi"
        			+ "		{"
        			+ "		    position:absolute;"
        			+ "			transform: translate(0, -50%);"
        			+ "		    top:60%;"
        			+ "			font-size: 56px;"
        			+ "			color: var(--blue2);"
        			+ "			padding-left:100px;"
        			+ "		}"
        			+ "		.menu"
        			+ "		{"
        			+ "			font-family: Montserrat, sans-serif;"
        			+ "			text-orientation: upright; "
        			+ "			writing-mode: vertical-rl;"
        			+ "			color: white;"
        			+ "			font-size:36px;"
        			+ "			position:absolute;"
        			+ "			transform: translate(0, -50%);"
        			+ "		    top:50%;"
        			+ "		}"
        			+ "		.item1"
        			+ "		{"
        			+ "			font-family: Montserrat, sans-serif;"
        			+ "			background-color: var(--blue2);"
        			+ "  		    z-index: 9999;"
        			+ "			font-size:30px;"
        			+ "			position: fixed;"
        			+ "			width: 100%;"
        			+ "		}"
        			+ "		.item1 a"
        			+ "		{"
        			+ "			float: right;"
        			+ "			color:white;"
        			+ "			background-color: var(--blue2);"
        			+ "			text-align: center;"
        			+ "			padding: 16px 16px;"
        			+ "			line-height: 1.42857143 !important;"
        			+ "			letter-spacing: 4px;"
        			+ "			text-decoration: none;"
        			+ "			font-size: 16px;"
        			+ "			z-index: 9999;"
        			+ "			font-weight: 120;"
        			+ "		}"
        			+ "		.item1 a:hover {"
        			+ "			  background-color: var(--white);"
        			+ "			  color: black;"
        			+ "			  z-index: 9999;"
        			+ "			}"
        			+ "		.upload	"
        			+ "		{"
        			+ "			"
        			+ "			padding:40px;"
        			+ "		}"
        			+ "		"
        			+ "		.container"
        			+ "		{"
        			+ "		   display: grid;"
        			+ "		   margin-left:75px;"
        			+ "		   margin-top:70px;"
        			+ "		   margin-right:10px;"
        			+ "		   text-align:center;"
        			+ "		}"
        			+ "		.num"
        			+ "		{"
        			+ "			font-size:18px;"
        			+ "			margin-left:145px;"
        			+ "			margin-top:70px;"
        			+ "			display: grid;"
        			+ "		}"
        			+ "		.question"
        			+ "		{"
        			+ "			font-size:18px;"
        			+ "			display: grid;"
        			+ "			margin-left:175px;"
        			+ "			width:80%;"
        			+ "			height: 150px;"
        			+ "		}"
        			+ "		"
        			+ "		.qty"
        			+ "		{"
        			+ "			background-color:var(--blue2);"
        			+ "			color:white;"
        			+ "			padding-left:20px;"
        			+ "			font-size:18px;"
        			+ "			display: grid;"
        			+ "			margin-top:50px;"
        			+ "			margin-left:175px;"
        			+ "			width:80%;"
        			+ "			height: 50px;"
        			+ "		}"
        			+ "		::-webkit-input-placeholder { /* Edge */"
        			+ "		  padding-left: 50px;"
        			+ "		}"
        			+ "		"
        			+ "		:-ms-input-placeholder { /* Internet Explorer 10-11 */"
        			+ "		  margin-left: 20px;"
        			+ "		}"
        			+ "		::placeholder {"
        			+ "		  margin-left: 20px;"
        			+ "		}"
        			+ "		"
        			+ "		.buttons"
        			+ "		{"
        			+ "			margin-left:175px;"
        			+ "			margin-top:50px;"
        			+ "		}"
        			+ "		"
        			+ "		.button_orange{"
        			+ "		  background-color: var(--orange1);"
        			+ "		  padding: 10px;"
        			+ "		  width: 170px;"
        			+ "		  color:white;"
        			+ "		  border: none;  "
        			+ "		}"
        			+ "		.button_blue{"
        			+ "		  background-color: var(--blue2);"
        			+ "		  padding: 10px;"
        			+ "		  width: 170px;"
        			+ "		  color:white;"
        			+ "		  border: none;  "
        			+ "		}"
        			+ "		.button_blue1{"
        			+ "		  background-color: var(--blue1);"
        			+ "		  padding-top: 10px;"
        			+ "		  padding-bottom: 10px;"
        			+ "		  padding-left: 30px;"
        			+ "		  padding-right: 30px;"
        			+ "		  border: none;  "
        			+ "		}"
        			+ "		.qsub{"
        			+ "		  background-color: var(--orange1);"
        			+ "		  padding: 10px;"
        			+ "		  width: 170px;"
        			+ "		  color:white;"
        			+ "		  border: none;  "
        			+ "	      text-decoration:none;"
        			+ "		}"
        			+ "		.question"
        			+ "		{"
        			+ "			font-size:18px;"
        			+ "			display: grid;"
        			+ "			margin-left:175px;"
        			+ "			width:80%;"
        			+ "		}"
        			+ "		"
        			+ "		.longAns"
        			+ "		{"
        			+ "			font-size:18px;"
        			+ "			margin-left:175px;"
        			+ "			margin-top:50px;"
        			+ "			width:80%;"
        			+ "			height: 200px;"
        			+ "		}"
        			+ "		"
        			+ "		.shortAns"
        			+ "		{"
        			+ "			font-size:18px;"
        			+ "			display: grid;"
        			+ "			margin-left:175px;"
        			+ "			margin-top:50px;"
        			+ "			width:80%;"
        			+ "			height: 100px;"
        			+ "		}"
        			+ "		"
        			+ "		.mcq"
        			+ "		{"
        			+ "			display:grid;"
        			+ "			grid-template-columns: auto auto;"
        			+ "			margin-left:175px;"
        			+ "			margin-top:50px;"
        			+ "			width:80%;"
        			+ "		}"
        			+ "		"
        			+ "		.opt"
        			+ "		{"
        			+ "			height:50px;"
        			+ "			width:300px;"
        			+ "			margin-bottom:30px;"
        			+ "		}"
        			+ "		"
        			+ "		.tf"
        			+ "		{"
        			+ "			margin-left:175px;"
        			+ "			margin-top:50px;"
        			+ "			width:80%;"
        			+ "		}"
        			+ "	</style>"
        			+ "</head>"
        			+ "  "
        			+ "<body>"
        			+ "	<div class=\"item1\">"
        			+ "		  "
        			+ "		  <a href=\"Logout\">LOGOUT</a>"
        			+ "		  <a class=\"active\" href=\"PaperSetter\">HOME</a>"
        			+ "		  <img src=\"test.png\" width=\"50px;\" height=\"50px;\" style=\"position:absolute; left:200px; top:0px;\"><div style=\"color:white; position:absolute; left:80px; top:10px;\">DigiTest</div>"
        			+ "	</div>"
        			+ "	<div class=\"test\" id=\"demo\" onmouseover=\"slide()\" onmouseout=\"hide()\">"
        			+ "		<table>"
        			+ "			<tr>"
        			+ "			<td><img src=\"plus-sign.png\" width=40px; height=40px; style=\"margin-left:10px;\"></td><td><a href=\"#\">Create</a></td>"
        			+ "			</tr>"
        			+ "			<tr>"
        			+ "			<td><img src=\"edit-list.png\" width=40px; height=40px; style=\"margin-left:10px;\"></td><td><a href=\"#\">Edit</a></td>"
        			+ "			</tr>"
        			+ "			<tr>"
        			+ "			<td><img src=\"setting.png\" width=40px; height=40px; style=\"margin-left:10px;\"></td><td><a href=\"#\">Settings</a></td>"
        			+ "			</tr>"
        			+ "			<tr>"
        			+ "			<td><img src=\"power-off.png\" width=40px; height=40px; style=\"margin-left:10px;\"></td><td><a href=\"Logout\">Logout</a></td>"
        			+ "			</tr>"
        			+ "		</table>"
        			+ "	</div>"
        			+ "<div class=\"container\" style=\"color:var(--blue2);\"><h1>REVIEW QUESTION PAPER</h1></div>"
        			);
        	out.println("<table style='margin-left:300px; margin-top:50px; width:800px; border:none;'>");
        	 while(rs.next())
             {
        		int i = rs.getInt("qid");
        		out.println("<form action=\"editQuestion\"><tr style='background-color:var(--orange1)'><td colspan='2'  style='padding-left:10px;'><h3> Question - " + i + "</h3></td></tr>");
        		out.println("<tr style='padding:10px;'>");
        		String qtype = rs.getString("qtype");
        		out.println("<input type='hidden' name='qtype' value='" + qtype + "'>");
        		out.println("<input type='hidden' name='tbname' value='" + t + "'>");
        		out.println("<input type='hidden' name='qid' value='" + i + "'>");
    			out.println("<td><h3><input type='text' value='" + rs.getString("ques") + "' name='ques' style='font-weight:bold; width:100%; height:25px; '></h3></td>"
    			+ "<td style='text-align:right;'>Mark: <input type='text' value='" + rs.getString("mark") +"' name='mark' style='width:30px;'></td></tr>");
    			
             	if(qtype.equals("tf"))
             	{
             		if(rs.getString("ans").equals("True"))
             		{
             			out.println("<tr>"
                    			+ "	<td><input type=\"radio\" name=\"ans\" value=\"True\"  checked><label>True</label></td>"
                    			+ "�<td><input type=\"radio\" name=\"ans\" value=\"False\" style=\"margin-left:20px;\"><label>False</label></td>"
                    			+ "</tr>");
             		}
             		else
             		{
             			out.println("<tr>"
                    			+ "<td><input type=\"radio\" name=\"ans\" value=\"True\" ><label>True</label></td>"
                    			+ "<td><input type=\"radio\" name=\"ans\" value=\"False\" style=\"margin-left:20px;\" checked><label>False</label></td>"
                    			+ "	</tr>");
             		}
             	}
             	else if( !(qtype.equals("longAns") || qtype.equals("shortAns") || qtype.equals("oral")))
             	{
             		out.println("<tr>"
                			+ "		<td>&nbsp&nbsp&nbsp a) &nbsp <input type='text' value='" + rs.getString("a") + "' name='a'></td>"
                			+ "		<td style='text-align:reft'>b) &nbsp <input type='text' value='" + rs.getString("b") + "' name='b'></td></tr>"
                			+ "	<tr><td>&nbsp&nbsp&nbsp c) &nbsp <input type='text' value='" + rs.getString("c") + "' name='c'></td>"
                			+ "		<td style='text-align:left'>d) &nbsp <input type='text' value='" + rs.getString("d") + "' name='d'></td>"
                			+ "	</tr>");
             	}
             	out.println("<tr><td colspan='2' style='padding-bottom:20px; padding-top:20px;'><b>Correct answer:</b> &nbsp&nbsp&nbsp <input type='text' value='" + rs.getString("ans") + "' name='cor'></td></tr>");
             	out.println("<tr ><td colspan='2' style='padding-bottom:50px;'>"
         				+ "<input type='submit' value='save' class='button_blue1'>"
         				+ "</td></tr></form>");             }
    
        			out.println( "</table>"
        			+ "<button onclick='window.location=\"QuestionPaper\"' style='margin-left:300px; margin-bottom:50px;' class='button_blue'>ADD QUESTION</button>"
        			+ "<button onclick='window.location=\"onSub\"' style='margin-left:20px; margin-bottom:50px;' class='button_blue'>SUBMIT</button>"
        			+ "</body>"
        			+ "  <script>"
        			+ "      function slide()"
        			+ "      {"
        			+ "    	  document.getElementById(\"demo\").style.width = \"250px\";"
        			+ "    	  document.getElementById(\"menu\").style.color = \"var(--blue2)\";"
        			+ "      }"
        			+ "      "
        			+ "      function hide()"
        			+ "      {"
        			+ "    	  document.getElementById(\"demo\").style.width = \"65px\";"
        			+ "    	  document.getElementById(\"menu\").style.color = \"white\";"
        			+ "      }"
        			+ "      "
        			+ "      function show()"
        			+ "      {"
        			+ "    	  var x = document.getElementById(\"options\").value;"
        			+ "		  alert(x);"
        			+ "    	  if(x==\"tf\")"
        			+ "    		  {"
        			+ "    		     document.getElementById(\"tf\").style.display = \"block\";  "
        			+ "    		     document.getElementById(\"longAns\").style.display = \"none\";  "
        			+ "    		  }"
        			+ "    	  else if(x!=\"longAns\" && x!=\"shortAns\" && x!=\"oral\")"
        			+ "    		  {"
        			+ "    		     document.getElementById(\"mcq\").style.display = \"grid\";  "
        			+ "    		     document.getElementById(\"longAns\").style.display = \"grid\";  "
        			+ "    		  }"
        			+ "    	  else if(x==\"oral\")"
        			+ "    		  {"
        			+ "    		     document.getElementById(\"mcq\").style.display = \"grid\";  "
        			+ "    		     document.getElementById(\"longAns\").style.display = \"grid\";  "
        			+ "    		  }"
        			+ "    	  "
        			+ "      }"
        			+ "      "
        			+ "      let f = 1;"
        			+ "      function rec()"
        			+ "      {"
        			+ "    	  if (f==1)"
        			+ "    		  {"
        			+ "    		  		document.getElementById(\"rc\").style.color = \"white\";"
        			+ "    		  		document.getElementById(\"rc\").style.backgroundcolor = \"black\";"
        			+ "    		  		"
        			+ "    		  }"
        			+ "      }"
        			+ " </script> "
        			+ "</html>");
            }
        }
        catch(Exception e)
        {
        	System.out.println(e);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
