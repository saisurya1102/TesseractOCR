package Pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class createVar1 extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
        	HttpSession session = request.getSession();
        	String t = request.getParameter("tablename");
            
            Class.forName("com.mysql.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/tesseractocr", "root", "");
            Statement stmt = connection.createStatement();
            Statement stmt1 = connection.createStatement();
            String sql = "";
            
            int qid = 1;
           
            sql = "CREATE TABLE " + t + "Final ("
            		+ "    qid int AUTO_INCREMENT,"
            		+ "    qtype varchar(255),"
            		+ "    ques varchar(255),"
            		+ "    a varchar(255),"
            		+ "    b varchar(255),"
            		+ "    c varchar(255),"
            		+ "    d varchar(255),"
            		+ "    mark int(255),"
            		+ "	   ans varchar(255),"
            		+ "	   PRIMARY KEY ( qid )"
            		+ ");";
            
            
            stmt.executeUpdate(sql);
            
            sql = "select * from " + t;
            ResultSet rs = rs = stmt.executeQuery(sql);
            
            while(rs.next())
            {
            	qid = rs.getInt("qid");
            	String qtype = rs.getString("qtype");
            	String ques = rs.getString("ques");
            	String a = rs.getString("a");
            	String b = rs.getString("b");
            	String c = rs.getString("c");
            	String d = rs.getString("d");
            	String cor = rs.getString("ans");
            	int mark = rs.getInt("mark");
            	
            	String insert =  "INSERT INTO " + t + "Final "
                        + "(qid, qtype, ques, a, b, c, d,mark, ans) "
                        + "VALUES (NULL ,'" + qtype + "', '" + ques + "','" + a + "', '" + b + "', '" + c + "','"+ d + "','" + mark + "','" + cor + "')";

            	int row1 = stmt1.executeUpdate(insert);
            }
            session.setAttribute("qnum", qid);
            session.setAttribute("tname", t + "Final");
            response.sendRedirect("reviewPaper");
            
        }
        catch(Exception e)
        {
        	System.out.println(e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
