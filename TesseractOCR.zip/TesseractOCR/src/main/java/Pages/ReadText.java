package Pages;

import static org.bytedeco.javacpp.opencv_core.BORDER_DEFAULT;
import static org.bytedeco.javacpp.opencv_core.CV_32FC1;
import static org.bytedeco.javacpp.opencv_core.IPL_DEPTH_8U;
import static org.bytedeco.javacpp.opencv_core.cvCloneImage;
import static org.bytedeco.javacpp.opencv_core.cvCopy;
import static org.bytedeco.javacpp.opencv_core.cvCreateImage;
import static org.bytedeco.javacpp.opencv_core.cvCreateMat;
import static org.bytedeco.javacpp.opencv_core.cvGetSeqElem;
import static org.bytedeco.javacpp.opencv_core.cvGetSize;
import static org.bytedeco.javacpp.opencv_core.cvRect;
import static org.bytedeco.javacpp.opencv_core.cvReleaseImage;
import static org.bytedeco.javacpp.opencv_core.cvSetImageROI;
import static org.bytedeco.javacpp.opencv_core.cvSize;
import static org.bytedeco.javacpp.opencv_imgcodecs.cvLoadImage;
import static org.bytedeco.javacpp.opencv_imgcodecs.cvSaveImage;
import static org.bytedeco.javacpp.opencv_imgproc.CV_BGR2GRAY;
import static org.bytedeco.javacpp.opencv_imgproc.CV_CHAIN_APPROX_SIMPLE;
import static org.bytedeco.javacpp.opencv_imgproc.CV_INTER_LINEAR;
import static org.bytedeco.javacpp.opencv_imgproc.CV_MEDIAN;
import static org.bytedeco.javacpp.opencv_imgproc.CV_POLY_APPROX_DP;
import static org.bytedeco.javacpp.opencv_imgproc.CV_RETR_LIST;
import static org.bytedeco.javacpp.opencv_imgproc.CV_THRESH_OTSU;
import static org.bytedeco.javacpp.opencv_imgproc.cvApproxPoly;
import static org.bytedeco.javacpp.opencv_imgproc.cvBoundingRect;
import static org.bytedeco.javacpp.opencv_imgproc.cvContourPerimeter;
import static org.bytedeco.javacpp.opencv_imgproc.cvCvtColor;
import static org.bytedeco.javacpp.opencv_imgproc.cvDrawCircle;
import static org.bytedeco.javacpp.opencv_imgproc.cvFindContours;
import static org.bytedeco.javacpp.opencv_imgproc.cvGetPerspectiveTransform;
import static org.bytedeco.javacpp.opencv_imgproc.cvSmooth;
import static org.bytedeco.javacpp.opencv_imgproc.cvThreshold;
import static org.bytedeco.javacpp.opencv_imgproc.cvWarpPerspective;
import java.io.File;
import java.net.URL;
import org.bytedeco.javacpp.BytePointer;
import org.bytedeco.javacpp.Loader;
import org.bytedeco.javacpp.lept.PIX;
import org.bytedeco.javacpp.opencv_core;
import org.bytedeco.javacpp.opencv_core.CvContour;
import org.bytedeco.javacpp.opencv_core.CvMat;
import org.bytedeco.javacpp.opencv_core.CvMemStorage;
import org.bytedeco.javacpp.opencv_core.CvPoint;
import org.bytedeco.javacpp.opencv_core.CvRect;
import org.bytedeco.javacpp.opencv_core.CvScalar;
import org.bytedeco.javacpp.opencv_core.CvSeq;
import org.bytedeco.javacpp.opencv_core.IplImage;
import org.bytedeco.javacpp.opencv_core.Mat;
import org.bytedeco.javacpp.opencv_core.Size;
import org.bytedeco.javacpp.opencv_imgproc;
import org.bytedeco.javacpp.tesseract.TessBaseAPI;
import org.bytedeco.javacv.Frame;
import org.bytedeco.javacv.OpenCVFrameConverter;

import net.sourceforge.tess4j.Tesseract;

import static org.bytedeco.javacpp.lept.pixRead;
import static org.bytedeco.javacpp.lept.pixDestroy;

public final class ReadText implements ReceiptScanner{

	@Override
	public String getTextFromReceiptImage(final String receiptFileImagePath)
	{
		final File receiptImageFile = new File(receiptFileImagePath);
		final String receiptImagePathFile = receiptImageFile.getAbsolutePath();
		System.out.println(receiptImagePathFile);
		IplImage receiptImage = cvLoadImage(receiptImagePathFile);
		IplImage cannyEdgeImage = applyCannySquareEdgeDetectionOnImage(receiptImage, 30);
		/*CvSeq largestSquare = findLargestSquareOnCannyDetectedImage(cannyEdgeImage);
		receiptImage = applyPerspectiveTransformThresholdOnOriginalImage(receiptImage, largestSquare, 30);*/
		
		receiptImage = cleanImageSmoothingForOcr(receiptImage);
		
		final File cleanedReceiptFile = new File(receiptFileImagePath);
		final String cleanedReceiptPathFile = cleanedReceiptFile.getAbsolutePath();
		System.out.println(cleanedReceiptPathFile);
		
		cvSaveImage(cleanedReceiptPathFile, receiptImage);
		System.out.println(cleanedReceiptPathFile);
		
		cvReleaseImage(cannyEdgeImage);
		cannyEdgeImage = null;
		cvReleaseImage(receiptImage);
		receiptImage = null;
		return getStringFromImage(cleanedReceiptPathFile);
	}

	private IplImage downScaleImage(IplImage srcImage, int percent)
	{
		IplImage dest = cvCreateImage( cvSize( (srcImage.width()*percent)/100, (srcImage.height()*percent)/100 ), srcImage.depth(),
					srcImage.nChannels());
		System.out.println("dest - height - " + dest.height() + " , width - " + dest.width());
		opencv_imgproc.cvResize(srcImage, dest);
	    return dest;
	}
	
	private IplImage applyCannySquareEdgeDetectionOnImage(IplImage srcImage, int percent)
	{
		try {
			IplImage destImage = downScaleImage(srcImage, percent);
			IplImage grayImage = cvCreateImage(cvGetSize(destImage), IPL_DEPTH_8U, 1); 
			
			//Gray
			opencv_imgproc.cvCvtColor(destImage, grayImage, CV_BGR2GRAY); 
			OpenCVFrameConverter.ToMat converterToMat = new OpenCVFrameConverter.ToMat();
			Frame grayImageFrame = converterToMat.convert(grayImage);
			Mat grayImageMat = converterToMat.convert(grayImageFrame);
			System.out.println("Converted to gray");
			
			//Gaussian Blur
			opencv_imgproc.GaussianBlur(grayImageMat,  grayImageMat, new Size(3,3), 0.0, 0.0, BORDER_DEFAULT);
			destImage = converterToMat.convertToIplImage(grayImageFrame);
			System.out.println("Gaussian Blur");
			//Clean
			opencv_imgproc.cvErode(destImage, destImage);
			opencv_imgproc.cvDilate(destImage, destImage);
			System.out.println("Created clean image");
			//Canny
			opencv_imgproc.cvCanny(destImage, destImage, 75.0, 100.0);
			System.out.println("Applied canny");
			cvSaveImage("E:\\TCS\\rio\\test\\canny.jpg", destImage);
		    return destImage;
		}
		catch(Exception e)
		{
			System.out.println(e);
			return null;
		}
	}
	
	private CvSeq findLargestSquareOnCannyDetectedImage(IplImage cannyEdgeDetectedImage)
	{
		try {
			System.out.println("In Contours Transformed image......");
			IplImage foundedContoursImage = cvCloneImage(cannyEdgeDetectedImage);
			CvMemStorage memory =  CvMemStorage.create();
			CvSeq contours = new  CvSeq();
			cvFindContours(foundedContoursImage, memory, contours, Loader.sizeof(CvContour.class), CV_RETR_LIST, CV_CHAIN_APPROX_SIMPLE, opencv_core.cvPoint(0,0));
			System.out.println("Found Contours......");
			int maxWidth = 0;
			int maxHeight = 0;
			CvRect contour = null;
			CvSeq seqFounded = null;
			CvSeq nextSeq = new CvSeq();
			for(nextSeq = contours; nextSeq!=null; nextSeq.h_next())
			{
				
				contour = cvBoundingRect(nextSeq, 0);
				if((contour.width()>= maxWidth) && (contour.height()>=maxHeight))
				{
					System.out.println("In loop......");
					maxWidth = contour.width();
					maxHeight = contour.height();
					seqFounded = nextSeq;
				}
			}
			System.out.println("Max Width......" + maxWidth);
			System.out.println("Max Height......" + maxHeight);
			CvSeq result  = cvApproxPoly(seqFounded, Loader.sizeof(CvContour.class), memory, CV_POLY_APPROX_DP,
					cvContourPerimeter(seqFounded)*0.02, 0);
			
			for(int i=0; i<result.total(); i++)
			{
				CvPoint v = new CvPoint(cvGetSeqElem(result, i));
				cvDrawCircle(foundedContoursImage, v, 5, CvScalar.BLUE, 20, 8, 0);
			}
			System.out.println("Drew Cirlce......");
			File f = new File(System.getProperty("user.home") + File.separator + "receipt-find-contours-image.jpeg");
			cvSaveImage(f.getAbsolutePath(), foundedContoursImage);
			cvSaveImage("E:\\TCS\\rio\\test\\canny1.jpg", foundedContoursImage);
			System.out.println("Contours Transformed image");
			return result;
		}
		catch(Exception e)
		{
			System.out.println(e);
			return null;
		}
	}
	private IplImage applyPerspectiveTransformThresholdOnOriginalImage(
			IplImage srcImage,CvSeq contour, int percent)
	{
		IplImage warpImage = cvCloneImage(srcImage);
		for(int i=0; i<contour.total(); i++)
		{
			CvPoint point = new CvPoint(cvGetSeqElem(contour, i));
			point.x((int) (point.x()*100)/percent);
			point.y((int) (point.y()*100)/percent);
		}
		
		CvPoint topRightPoint = new CvPoint(cvGetSeqElem(contour, 0));
		CvPoint topLeftPoint = new CvPoint(cvGetSeqElem(contour, 1));
		CvPoint bottomLeftPoint = new CvPoint(cvGetSeqElem(contour, 2));
		CvPoint bottomRightPoint = new CvPoint(cvGetSeqElem(contour, 3));
		
		int resultWidth = (int) (topRightPoint.x() - topLeftPoint.x());
		int bottomWidth = (int) (bottomRightPoint.x() - bottomLeftPoint.x());
		
		if(bottomWidth >resultWidth)
		{
			resultWidth = bottomWidth;
		}
		
		int resultHeight = (int) (topRightPoint.y() - topLeftPoint.y());
		int bottomHeight = (int) (bottomRightPoint.y() - bottomLeftPoint.y());
		
		if(bottomHeight >resultHeight)
		{
			resultHeight = bottomHeight;
		}
		
		float [] sourcePoints = {topLeftPoint.x(), topLeftPoint.y(), topRightPoint.x(), topRightPoint.y(), 
				bottomLeftPoint.x(), bottomLeftPoint.y(), bottomRightPoint.x(), bottomRightPoint.y()};  
		
		float [] destinationPoints = {0, 0, resultWidth, 0, 0, resultHeight, resultWidth, resultHeight};
		
		CvMat homography = cvCreateMat(3,3, CV_32FC1);
		cvGetPerspectiveTransform(sourcePoints, destinationPoints, homography);
		IplImage destImage = cvCloneImage(warpImage);
		cvWarpPerspective(warpImage, destImage, homography, CV_INTER_LINEAR, CvScalar.ZERO);
		System.out.println("Perspective transformation");
		return cropImage(destImage, 0, 0, resultWidth, resultHeight);
	}
	
	private IplImage cropImage(IplImage srcImage, int fromX, int fromY, int toWidth, int toHeight)
	{
			cvSetImageROI(srcImage, cvRect(fromX, fromY, toWidth, toHeight));
			IplImage destImage = cvCloneImage(srcImage);
			cvCopy(srcImage, destImage);
			System.out.println("Cropped Image");
			return destImage;
	}
	private IplImage cleanImageSmoothingForOcr(IplImage srcImage)
	{
			IplImage destImage = cvCreateImage(cvGetSize(srcImage), IPL_DEPTH_8U, 1);
			cvCvtColor(srcImage, destImage, CV_BGR2GRAY);
			cvSmooth(destImage, destImage, CV_MEDIAN, 3, 0, 0, 0);
			cvThreshold(destImage, destImage, 0, 255, CV_THRESH_OTSU);
			System.out.println("Smoothened Image");
			return destImage;
	}
	
	private String getStringFromImage(final String pathToReceiptImageFile)
	{
		try {
			
			Tesseract tesseract = new Tesseract();
			tesseract.setDatapath("C:\\Users\\123\\Downloads\\Tess4J-3.4.8-src\\Tess4J\\tessdata");
	        String text = tesseract.doOCR(new File(pathToReceiptImageFile));
	        //System.out.print(text);
	        
	        return text;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
}
