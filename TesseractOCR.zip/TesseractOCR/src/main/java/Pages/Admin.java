package Pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author 123
 */
public class Admin extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
        	HttpSession session = request.getSession();
            String[] user = (String[]) session.getAttribute("user");
            if(user==null)
        	{
        		response.sendRedirect("index.jsp");
        	}
            else {
            String n = user[0];
            String org = user[1];
            String type = user[2];
            String admin = user[4];
        	out.println("<!DOCTYPE html>"
        			+ "<html>"
        			+ "<head>"
        			+ "<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js\"></script>"
        			+ ""
        			+ "<script>"
        			+ "$(document).ready(function(){"
        			+ " $(\"#reg\").hide();"
        			+ "  $(\"#shReg\").click(function(){"
        			+ "    $(\"#reg\").toggle();"
        			+ "  });"
        			+ "});"
        			+ "</script>"
        			+ ""
        			+ "<meta charset=\"ISO-8859-1\">"
        			+ "<style type=\"text/css\">"
        			+ ":root {"
        			+ "  	--orange1 : #f4511e;"
        			+ "	--orange2 : #8c0803;"
        			+ "	--blue1 : #95a8ac;"
        			+ "	--blue2 : #223745;"
        			+ "	--white : #ecebe2;"
        			+ "	--grey : #a8a194;"
        			+ "	--beige : #e0d2b4;"
        			+ "	--beigePink : #e4c9b4;"
        			+ "	--pink : #d0a292;"
        			+ "	--brown : #9b785e;"
        			+ "}"
        			+ "h2 {"
        			+ "    font-size: 24px;"
        			+ "    text-transform: uppercase;"
        			+ "    color: #303030;"
        			+ "    font-weight: 600;"
        			+ "    margin-bottom: 30px;"
        			+ "  }"
        			+ "  h4 {"
        			+ "    font-size: 19px;"
        			+ "    line-height: 1.375em;"
        			+ "    color: #303030;"
        			+ "    font-weight: 400;"
        			+ "    margin-bottom: 30px;"
        			+ "  }  "
        			+ ""
        			+ ""
        			+ ".topnav {"
        			+ "  overflow: hidden;"
        			+ "  background-color: var(--blue2);"
        			+ "  z-index: 9999;"
        			+ "  font-family: Montserrat, sans-serif;"
        			+ "  position: fixed;"
        			+ "  width: 100%;"
        			+ "}"
        			+ ""
        			+ ".topnav a {"
        			+ "  float: right;"
        			+ "  color: #f2f2f2;"
        			+ "  text-align: center;"
        			+ "  padding: 14px 16px;"
        			+ "  line-height: 1.42857143 !important;"
        			+ "  letter-spacing: 4px;"
        			+ "  text-decoration: none;"
        			+ "  font-size: 12px;"
        			+ "  z-index: 9999;"
        			+ "}"
        			+ ""
        			+ ".topnav a:hover {"
        			+ "  background-color: var(--white);"
        			+ "  color: black;"
        			+ "  z-index: 9999;"
        			+ "}"
        			+ ""
        			+ ".topnav a.active {"
        			+ "  background-color: var(--orange1);"
        			+ "  color: white;"
        			+ "  z-index: 9999;"
        			+ "}"
        			+ "body {"
        			+ "  margin: 0;"
        			+ "  "
        			+ "}"
        			+ ""
        			+ ".button_orange{"
        			+ " background-color: var(--orange1);"
        			+ " padding: 7px;"
        			+ " border-radius:3px;"
        			+ " color:white;"
        			+ " border: none;"
        			+ "}"
        			+ ""
        			+ ".button_blue{"
        			+ " background-color: var(--blue2);"
        			+ " padding: 7px;"
        			+ " border-radius:3px;"
        			+ " border: none;"
        			+ " color:white;"
        			+ "}"
        			+ ""
        			+ ".sidebar {"
        			+ "  height: 100%;"
        			+ "  width: 0;"
        			+ "  position: fixed;"
        			+ "  z-index: 1;"
        			+ "  top: 0;"
        			+ "  left: 0;"
        			+ "  background-color: #111;"
        			+ "  overflow-x: hidden;"
        			+ "  transition: 0.5s;"
        			+ "  padding-top: 60px;"
        			+ "}"
        			+ ""
        			+ ".sidebar a {"
        			+ "  padding: 40px 8px 8px 32px;"
        			+ "  text-decoration: none;"
        			+ "  font-size: 20px;"
        			+ "  position: relative;"
        			+ "  color: #818181;"
        			+ "  display: block;"
        			+ "  transition: 0.3s;"
        			+ "}"
        			+ ""
        			+ ".hide{"
        			+ " display:hide;"
        			+ "}"
        			+ ""
        			+ ".formLogin {"
        			+ "  padding: 10px 8px 8px 32px;"
        			+ "  text-decoration: none;"
        			+ "  font-size: 15px;"
        			+ "  position: relative;"
        			+ "  color: #818181;"
        			+ "  display: block;"
        			+ "  transition: 0.3s;"
        			+ "}"
        			+ ""
        			+ ".sidebar a:hover {"
        			+ "  color: #f1f1f1;"
        			+ "}"
        			+ ""
        			+ ".sidebar .closebtn {"
        			+ "  position: absolute;"
        			+ "  top: 0;"
        			+ "  right: 25px;"
        			+ "  font-size: 36px;"
        			+ "  margin-left: 50px;"
        			+ "}"
        			+ ""
        			+ ".openbtn {"
        			+ "  font-size: 12px;"
        			+ "  cursor: pointer;"
        			+ "  color: white;"
        			+ "  padding: 10px 15px;"
        			+ "  border: none;"
        			+ "}"
        			+ "		.qsub{"
        			+ "		  background-color: var(--orange1);"
        			+ "		  padding: 10px;"
        			+ "		  width: 170px;"
        			+ "		  color:white;"
        			+ "		  border: none;  "
        			+ "	      text-decoration:none;"
        			+ "		}"
        			+ "@media screen and (max-width: 768px) {"
        			+ "    .col-sm-4 {"
        			+ "      text-align: center;"
        			+ "      margin: 25px 0;"
        			+ "    }"
        			+ "}    "
        			+ " .container{"
        			+ " 	margin: 0px 20px 20px 20px;"
        			+ " 	padding-top: 50px;"
        			+ " 	max-width: 100%;"
        			+ "  	height: auto;"
        			+ " 	position:relative;"
        			+ " }"
        			+ " "
        			+ " .center {"
        			+ "  margin-left: auto;"
        			+ "  margin-right: auto;"
        			+ "}"
        			+ ".responsive {"
        			+ "  max-width: 100%;"
        			+ "  height: auto;"
        			+ "}"
        			+ ""
        			+ "</style>"
        			+ "<title>Digitize Question Paper</title>"
        			+ "</head>"
        			+ ""
        			+ "<body>"
        			+ "<!-- Login sidebar -->"
        			+ "<div id=\"mySidebar\" class=\"sidebar\">"
        			+ "  <a href=\"javascript:void(0)\" class=\"closebtn\" onclick=\"closeNav()\">�</a>"
        			+ "  <h3 style=\"color:white; padding-left:10px; padding-top:10px;\">Login</h3>"
        			+ "  <form action=\"Login\" method=\"post\" class=\"formLogin\">"
        			+ "  	<input type=\"email\" placeholder=\"email\" name=\"email\"><br><br>"
        			+ "  	<input type=\"password\" placeholder=\"password\" name=\"password\"><br><br>"
        			+ "  	<input type=\"submit\" class=\"button_orange\">"
        			+ "  </form>"
        			+ "</div>"
        			+ ""
        			+ "<!-- Navigation bar -->"
        			+ "<div class=\"topnav\">"
        			+ "  <a href=\"Logout\">LOGOUT</a>"
        			+ "  <a href='Ausers'>USERS</a>"
        			+ "  <a href=\"Admin\" class=\"active\">HOME</a>"
        			+ "</div>"
        			+ ""
        			+ ""
        			+ "<div class=\"container\">"
        			+ "<table width=\"100%\">"
        			+ "<col style=\"width:50%\">"
        			+ "<col style=\"width:50%\">"
        			+ "<tr>"
        			+ "<td style='width:30%; margin:30px; vertical-align: middle; padding-left:40px;'>"
        			+ "      <h2>Register Users</h2>"
        			+ "	<table>"
        			+ "      <form action=\"Register1\">"
        			+ "      	<tr>"
        			+ "      	<td><strong>Name:</strong></td>"
        			+ "      	<td><input type=\"text\" name=\"name\"></td>"
        			+ "      	</tr>"
        			+ "      	<tr>"
        			+ "      	<td><strong>User Type:</strong></td>"
        			+ "      	<td>"
        			+ "			<select name='t' id='t'>"
        			+ "				<option value='PaperSetter'>Paper Setter</option>"
        			+ "				<option value='Reviewer'>Reviewer</option>"
        			+ "			</select>"
        			+ "			</td>"
        			+ "      	</tr>"
        			+ "      	<tr>"
        			+ "      	<td><strong>Email:</strong></td>"
        			+ "      	<td><input type=\"email\" name=\"email\"></td>"
        			+ "      	</tr>"
        			+ "      	<tr>"
        			+ "      	<td><strong>Password:</strong></td>"
        			+ "      	<td><input type=\"password\" name=\"psw\"></td>"
        			+ "      	</tr>"
        			+ "      	<tr>"
        			+ "			 <input type=\"hidden\" id=\"org\" name=\"org\" value=" + org + ">"
        			+ "			 <input type=\"hidden\" id=\"adm\" name=\"adm\" value=" + n + ">"
        			+ "      	<td colspan=\"2\"><input type=\"submit\" class=\"button_orange\" name=\"Register\"></td>"
        			+ "      	</tr>"
        			+ "      </form>"
        			+ "      </table><br>"
        			+ "<p style='color:grey; font-size:12px;'>OR</p><br>"
        			+ "  <button class='button_blue' id='shReg'>Upload Users</button>"
        			+ "		<div id='reg' red'>"
        			
        			+ "      <table>"
        			+ "      <form action=\"UploadUsers\" enctype='multipart/form-data' method='post'><br>"
        			+ "      	<tr>"
        			+ "      	<td><strong>Upload Text File:</strong></td>"
        			+ "      	<td><input type=\"file\" name=\"file\"></td>"
        			+ "      	</tr>"
        			+ "      	<tr>"
        			+ "      	<td colspan=\"2\"><input type=\"submit\" class=\"sub\"></td>"
        			+ "      	</tr>"
        			+ "      </form>"
        			+ "      </table>"
        			+ "		</div>"
        			+ "  </td>"
        			+ "<td style=\"width:70%\">"
        			+ "      <span><img src=\"upload.jpg\" height=\"55%\" width=\"85%\"></span>"
        			+ "</td>"
        			+ "  </tr>"
        			+ "  </table>"
        			+ "</div>"
        			+ "<script>"
        			+ " function openNav() {"
        			+ "	  document.getElementById(\"mySidebar\").style.width = \"250px\";"
        			+ "	  document.getElementById(\"main\").style.marginLeft = \"250px\";"
        			+ "	}"
        			+ ""
        			+ "	function closeNav() {"
        			+ "	  document.getElementById(\"mySidebar\").style.width = \"0\";"
        			+ "	  document.getElementById(\"main\").style.marginLeft= \"0\";"
        			+ "	}"
        			+ " </script>"
        			+ "</body>"
        			+ "</html>"
        			+ ""
        			+ "");
            }
        }
        catch(Exception e)
        {
        	System.out.println(e);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
