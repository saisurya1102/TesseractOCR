package Pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class uploadQuestion extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
        	HttpSession session = request.getSession();
        	String t = (String) session.getAttribute("tname");
            String[] user = (String[]) session.getAttribute("user");
            int i = (int) session.getAttribute("qnum");
            if(user==null)
        	{
        		response.sendRedirect("index.jsp");
        	}
            else {
            String n = user[0];
            String org = user[1];
            String type = user[2];
            String admin = user[4];
        	String rev = request.getParameter("rev");
            String qname = request.getParameter("qname");
        	Class.forName("com.mysql.jdbc.Driver");
        	

            String mark = request.getParameter("mark");
            String qtype = request.getParameter("qtype");
            String ques = request.getParameter("ques");
            String a = request.getParameter("a");
            String b = request.getParameter("b");
            String c = request.getParameter("c");
            String d = request.getParameter("d");
            String cor = request.getParameter("cor");
            String ans = request.getParameter("ans");
            
            
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/tesseractocr", "root", "");
            Statement stmt = connection.createStatement();
            String sql ="";
            
            
            if(qtype.equals("tf"))
            {
            	sql =  "INSERT INTO " + t + " "
                        + "(qid, qtype, ques, a, b, c, d,mark, ans) "
                        + "VALUES (NULL ,'" + qtype + "','" + ques + "', 'True', 'False', '" + c + "','"+ d + "','" + mark + "','" + ans + "')";
                
            }
            else
            {
            	sql =  "INSERT INTO " + t + " "
                        + "(qid, qtype, ques, a, b, c, d,mark, ans) "
                        + "VALUES (NULL ,'" + qtype + "', '" + ques + "','" + a + "', '" + b + "', '" + c + "','"+ d + "','" + mark + "','" + cor + "')";
            }
            
            
            
            
            int row = stmt.executeUpdate(sql);
            i = i+1;
            session.setAttribute("qnum", i);
            session.setAttribute("tname", t);
            response.sendRedirect("QuestionPaper");
            }
        }
        catch(Exception e)
        {
        	System.out.println(e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
