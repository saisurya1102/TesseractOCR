package Pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class createPaper extends HttpServlet {


    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
        	HttpSession session = request.getSession();
        	String isDown = (String) session.getAttribute("isDown");
            String[] user = (String[]) session.getAttribute("user");
            if(user==null)
        	{
        		response.sendRedirect("index.jsp");
        	}
            else {
            String n = user[0];
            String org = user[1];
            String type = user[2];
            String admin = user[4];
        	out.println("<!DOCTYPE html>\r\n"
        			+ "<html>\r\n"
        			+ "  \r\n"
        			+ "<head>\r\n"
        			+ "	<meta charset=\"UTF-8\">\r\n"
        			+ "	\r\n"
        			+ "	<style> \r\n"
        			+ "	\r\n"
        			+ "	:root {\r\n"
        			+ "	  	--orange1 : #f4511e;\r\n"
        			+ "	  	--violet1: #d279d2;\r\n"
        			+ "	  	--violet2: #732673;\r\n"
        			+ "	  	--greyBlue: #29293d;\r\n"
        			+ "		--orange2 : #8c0803;\r\n"
        			+ "		--blue1 : #95a8ac;\r\n"
        			+ "		--blue2 : #223745;\r\n"
        			+ "		--white : #ecebe2;\r\n"
        			+ "		--grey : #a8a194;\r\n"
        			+ "		--beige : #e0d2b4;\r\n"
        			+ "		--beigePink : #e4c9b4;\r\n"
        			+ "		--pink : #d0a292;\r\n"
        			+ "		--brown : #9b785e;\r\n"
        			+ "	}\r\n"
        			+ "	\r\n"
        			+ "	html, body {\r\n"
        			+ "    max-width: 100%;\r\n"
        			+ "    overflow-x: hidden;\r\n"
        			+ "    margin:0;\r\n"
        			+ "	}\r\n"
        			+ "		.header\r\n"
        			+ "		{\r\n"
        			+ "		    height: 250px;\r\n"
        			+ "		    width: 90%;\r\n"
        			+ "		    transform: translate(-50%, 0);\r\n"
        			+ "		    left:50%;\r\n"
        			+ "		    position: absolute;\r\n"
        			+ "		    background-color:var(--white);\r\n"
        			+ "		    border-radius:25px;\r\n"
        			+ "		    margin-left:20px;\r\n"
        			+ "		    margin-top:70px;\r\n"
        			+ "		    margin-right:10px;\r\n"
        			+ "		}\r\n"
        			+ "		.test\r\n"
        			+ "		{\r\n"
        			+ "		    height: 100%;\r\n"
        			+ "			width: 65px;\r\n"
        			+ "			z-index:9999;\r\n"
        			+ "			position: fixed;\r\n"
        			+ "			background-color: var(--blue2);\r\n"
        			+ "			top: 0;\r\n"
        			+ "			left: 0;\r\n"
        			+ "			overflow-x: hidden;\r\n"
        			+ "			transition: 0.5s;\r\n"
        			+ "			padding-top: 100px;\r\n"
        			+ "		}\r\n"
        			+ "		\r\n"
        			+ "		.test a\r\n"
        			+ "		{\r\n"
        			+ "		 	padding-left:50px;\r\n"
        			+ "		 	padding-top:30px;\r\n"
        			+ "		 	padding-bottom:30px;\r\n"
        			+ "			line-height: 1.42857143 !important;\r\n"
        			+ "			letter-spacing: 4px;\r\n"
        			+ "			text-decoration: none;\r\n"
        			+ "			font-size: 20px;\r\n"
        			+ "			z-index: 9999;\r\n"
        			+ "			font-weight: bold;\r\n"
        			+ "			text-transform: uppercase;\r\n"
        			+ "			position: relative;\r\n"
        			+ "			color: white;\r\n"
        			+ "			display: block;\r\n"
        			+ "			transition: 0.3s;\r\n"
        			+ "		}\r\n"
        			+ "		\r\n"
        			+ "		.test a:hover\r\n"
        			+ "		{\r\n"
        			+ "			text-decoration: none;\r\n"
        			+ "			font-size: 20px;\r\n"
        			+ "			position: relative;\r\n"
        			+ "			color: white;\r\n"
        			+ "			display: block;\r\n"
        			+ "			transition: 0.3s;\r\n"
        			+ "			background-color: grey;\r\n"
        			+ "		}\r\n"
        			+ "		\r\n"
        			+ "		.hi\r\n"
        			+ "		{\r\n"
        			+ "		    position:absolute;\r\n"
        			+ "			transform: translate(0, -50%);\r\n"
        			+ "		    top:60%;\r\n"
        			+ "			font-size: 56px;\r\n"
        			+ "			color: var(--blue2);\r\n"
        			+ "			padding-left:100px;\r\n"
        			+ "		}\r\n"
        			+ "		.menu\r\n"
        			+ "		{\r\n"
        			+ "			font-family: Montserrat, sans-serif;\r\n"
        			+ "			text-orientation: upright; \r\n"
        			+ "			writing-mode: vertical-rl;\r\n"
        			+ "			color: white;\r\n"
        			+ "			font-size:36px;\r\n"
        			+ "			position:absolute;\r\n"
        			+ "			transform: translate(0, -50%);\r\n"
        			+ "		    top:50%;\r\n"
        			+ "		}\r\n"
        			+ "		.item1\r\n"
        			+ "		{\r\n"
        			+ "			font-family: Montserrat, sans-serif;\r\n"
        			+ "			background-color: var(--blue2);\r\n"
        			+ "  		    z-index: 9999;\r\n"
        			+ "			font-size:30px;\r\n"
        			+ "			position: fixed;\r\n"
        			+ "			width: 100%;\r\n"
        			+ "		}\r\n"
        			+ "		.item1\r\n"
        			+ "		{\r\n"
        			+ "			font-family: Montserrat, sans-serif;\r\n"
        			+ "			background-color: var(--blue2);\r\n"
        			+ "  		    z-index: 9999;\r\n"
        			+ "			font-size:30px;\r\n"
        			+ "			position: fixed;\r\n"
        			+ "			width: 100%;\r\n"
        			+ "		}\r\n"
        			+ "		.item1 a\r\n"
        			+ "		{\r\n"
        			+ "			float: right;\r\n"
        			+ "			color:white;\r\n"
        			+ "			background-color: var(--blue2);\r\n"
        			+ "			text-align: center;\r\n"
        			+ "			padding: 16px 16px;\r\n"
        			+ "			line-height: 1.42857143 !important;\r\n"
        			+ "			letter-spacing: 4px;\r\n"
        			+ "			text-decoration: none;\r\n"
        			+ "			font-size: 16px;\r\n"
        			+ "			z-index: 9999;\r\n"
        			+ "			font-weight: 120;\r\n"
        			+ "		}\r\n"
        			+ "		.item1 a:hover {\r\n"
        			+ "			  background-color: var(--white);\r\n"
        			+ "			  color: black;\r\n"
        			+ "			  z-index: 9999;\r\n"
        			+ "			}\r\n"
        			+ "		.upload	\r\n"
        			+ "		{\r\n"
        			+ "			\r\n"
        			+ "			padding:40px;\r\n"
        			+ "		}\r\n"
        			+ "	</style>\r\n"
        			+ "</head>\r\n"
        			+ "  \r\n"
        			+ "<body>\r\n"
        			+ "	<div class=\"item1\">\r\n"
        			+ "		  \r\n"
        			+ "		  <a href=\"Logout\">LOGOUT</a>\r\n"
        			+ "		  <a class=\"active\" href=\"PaperSetter\">HOME</a>\r\n"
        			+ "		  <img src=\"test.png\" width=\"50px;\" height=\"50px;\" style=\"position:absolute; left:200px; top:0px;\"><div style=\"color:white; position:absolute; left:80px; top:10px;\">DigiTest</div>"
        			+ "	</div>\r\n"
        			+ "	<div class=\"test\" id=\"demo\" onmouseover=\"slide()\" onmouseout=\"hide()\">\r\n"
        			+ "		<table>\r\n"
        			+ "			<tr>\r\n"
        			+ "			<td><img src=\"plus-sign.png\" width=40px; height=40px; style=\"margin-left:10px;\"></td><td><a href=\"#\">Create</a></td>\r\n"
        			+ "			</tr>\r\n"
        			+ "			<tr>\r\n"
        			+ "			<td><img src=\"edit-list.png\" width=40px; height=40px; style=\"margin-left:10px;\"></td><td><a href=\"#\">Edit</a></td>\r\n"
        			+ "			</tr>\r\n"
        			+ "			<tr>\r\n"
        			+ "			<td><img src=\"setting.png\" width=40px; height=40px; style=\"margin-left:10px;\"></td><td><a href=\"#\">Settings</a></td>\r\n"
        			+ "			</tr>\r\n"
        			+ "			<tr>\r\n"
        			+ "			<td><img src=\"power-off.png\" width=40px; height=40px; style=\"margin-left:10px;\"></td><td><a href=\"Logout\">Logout</a></td>\r\n"
        			+ "			</tr>\r\n"
        			+ "		</table>\r\n"
        			+ "	</div>\r\n"
        			+ "	<div class=\"papers\"></div>\r\n"
        			+ "	<div class=\"upload\">\r\n"
        			+ "	<table width=\"100%\">\r\n"
        			+ "		<col style=\"width:50%\">\r\n"
        			+ "		<col style=\"width:50%\">\r\n"
        			+ "		<tr>\r\n"
        			+ "		<td style=\"width:65%\">\r\n"
        			+ "		      <span><img src=\"upload.jpg\" height=\"600px\" width=600px;\"style=\"margin-left:50px;\"></span>\r\n"
        			+ "		</td>\r\n"
        			+ "		<td style=\"width:35%;\">\r\n"
        			+ "			  <div>\r\n"
        			+ "		      <h1>Upload Files</h1>\r\n"
        			+ "		      <table>\r\n"
        			+ "		      <form action=\"UploadFiles\" enctype='multipart/form-data' method='post'><br>\r\n"
        			+ "        			<tr>\r\n"
        			+ "        			<td><strong>Upload Text File:</strong></td>\r\n"
        			+ "        			<td><input type=\"file\" name=\"file\" multiple></td>\r\n"
        			+ "        			</tr>\r\n"
        			+ "        			<tr>\r\n"
        			+ "        			<td colspan=\"2\"><input type=\"submit\" value=\"Upload File\" class=\"sub\"></td>\r\n"
        			+ "        			</tr>\r\n");
        			
        			if(isDown.equals("Yes"))
        			{
        				out.println(  "					<tr>\r\n"
        	
        				+ "        			<td><div width=\"100%\" id=\"down\" style=\"color:green;\"><h2>Download Complete!</h2></div>"
        				+ "					</td>\r\n"
        				+ "        			</tr>");
        			}		
        			out.println( "        	  </form>\r\n"
        					+ "<tr><td>"
        					+ "<button class='button_orange' onclick=\"window.location.href='QuestionPaper';\">Create Paper</button>"
        			+ "			</td></tr>	"
        			+ "	      </table>\r\n"
        			+ "		      </div>\r\n"
        			+ "		  </td>\r\n"
        			+ "		  </tr>\r\n"
        			+ "		  </table>\r\n"
        			+ "		</div>\r\n"
        			+ "</body>\r\n"
        			+ "  <script>\r\n"
        			+ "      function slide()\r\n"
        			+ "      {\r\n"
        			+ "    	  document.getElementById(\"demo\").style.width = \"250px\";\r\n"
        			+ "    	  document.getElementById(\"menu\").style.color = \"var(--blue2)\";\r\n"
        			+ "      }\r\n"
        			+ "      \r\n"
        			+ "      function hide()\r\n"
        			+ "      {\r\n"
        			+ "    	  document.getElementById(\"demo\").style.width = \"65px\";\r\n"
        			+ "    	  document.getElementById(\"menu\").style.color = \"white\";\r\n"
        			+ "      }\r\n"
        			+ " </script> \r\n"
        			+ "</html>");
        		int i = 1;
        		session.setAttribute("qnum", i);
            }
        }
        catch(Exception e)
        {
        	System.out.println(e);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
