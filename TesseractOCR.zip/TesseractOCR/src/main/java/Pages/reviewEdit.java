package Pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class reviewEdit extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
        	HttpSession session = request.getSession();
            String[] user = (String[]) session.getAttribute("user");
            if(user==null)
        	{
        		response.sendRedirect("index.jsp");
        	}
            else {
            String n = user[0];
            String org = user[1];
            String type = user[2];
            String admin = user[4];
            
        	Class.forName("com.mysql.jdbc.Driver");
        	Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/tesseractocr", "root", "");
            Statement stmt = connection.createStatement();
            
            String mark = request.getParameter("mark");
            String qtype = request.getParameter("qtype");
            String qid =  request.getParameter("qid");
            String ques = request.getParameter("ques");
            String t = request.getParameter("tbname");
            if(qtype.equals("longAns") || qtype.equals("shortAns") || qtype.equals("oral"))
            {

                String cor = request.getParameter("cor");
                String sql = "UPDATE " + t + " "
                		+ "SET ques = '" +  ques + "', mark = " + Integer.parseInt(mark) + ", ans = '" + cor + "' "
                		+ "WHERE qid = " + qid + ";";
                int row = stmt.executeUpdate(sql);
                
            }
            else if (qtype.equals("tf"))
            {

                String ans = request.getParameter("ans");
                String sql = "UPDATE " + t + " "
                		+ "SET ques = '" +  ques + "', mark = " + Integer.parseInt(mark) + ", ans = '" + ans + "' "
                		+ "WHERE qid = " + qid + ";";
                int row = stmt.executeUpdate(sql);
            }
            else
            {
            	String a = request.getParameter("a");
                String b = request.getParameter("b");
                String c = request.getParameter("c");
                String d = request.getParameter("d");
                String cor = request.getParameter("cor");
                
                String sql = "UPDATE " + t + " "
                		+ "SET ques = '" +  ques + "', mark = " + Integer.parseInt(mark) + " , a = '" + a + "' , b = '" + b + "', c = '"+ c + "', d = '" + d + "', ans = '" + cor + "' "
                		+ "WHERE qid = " + qid + ";";
                int row = stmt.executeUpdate(sql);
            }
            
            response.sendRedirect("reviewPaper?tablename="+t);
            }
        }
        catch(Exception e)
        {
        	System.out.println(e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
