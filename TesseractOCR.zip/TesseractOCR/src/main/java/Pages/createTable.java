package Pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class createTable extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
        	HttpSession session = request.getSession();
        	String isDown = (String) session.getAttribute("isDown");
            String[] user = (String[]) session.getAttribute("user");
            if(user==null)
        	{
        		response.sendRedirect("index.jsp");
        	}
            else {
            String n = user[0];
            String org = user[1];
            String type = user[2];
            String id = user[3];
            String admin = user[4];
            
            String rev = request.getParameter("rev");
            String qname = request.getParameter("qname");
            String t = "test" + id + "" + admin + rev;
        	Class.forName("com.mysql.jdbc.Driver");
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/tesseractocr", "root", "");
            Statement stmt = connection.createStatement();
            String sql = "INSERT INTO questionpaper "
                    + "(Qid, Qname, PaperSetter, Reviewer, Status, admin, tablename) "
                    + "VALUES (NULL ,'" + qname + "', '" + id + "', '" + rev + "','"+ "Not Reviewed" + "','" + admin + "', '')";
            
            int row = stmt.executeUpdate(sql);
            out.println("<h1>Value Inserted!</h1>");
            
            sql = "SELECT * FROM questionpaper ORDER BY Qid DESC LIMIT 1";
            
            ResultSet rs = stmt.executeQuery(sql);
            int qid = 1;
            while(rs.next())
            {
            	qid = rs.getInt("Qid");
            	t = rs.getInt("Qid") + "test" +t;
            }
            
            sql = "CREATE TABLE " + t + " ("
            		+ "    qid int AUTO_INCREMENT,"
            		+ "    qtype varchar(255),"
            		+ "    ques varchar(255),"
            		+ "    a varchar(255),"
            		+ "    b varchar(255),"
            		+ "    c varchar(255),"
            		+ "    d varchar(255),"
            		+ "    mark int(255),"
            		+ "	   ans varchar(255),"
            		+ "	   PRIMARY KEY ( qid )"
            		+ ");";
            stmt.executeUpdate(sql);
            
            sql = "UPDATE questionpaper SET tablename = '" + t + "' WHERE qid = " + qid;
            stmt.executeUpdate(sql);
        	out.println("<h1>Table Created!</h1>");
        	session.setAttribute("tname", t);
        	response.sendRedirect("createPaper");
           }
        }
        catch(Exception e)
        {
        	System.out.println(e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
