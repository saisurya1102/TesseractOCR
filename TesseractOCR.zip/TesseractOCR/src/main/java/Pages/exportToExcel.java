package Pages;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class exportToExcel extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
        	HttpSession session = request.getSession();
            String[] user = (String[]) session.getAttribute("user");
            if(user==null)
        	{
        		response.sendRedirect("index.jsp");
        	}
            else {
            String n = user[0];
            String org = user[1];
            String type = user[2];
            String admin = user[4];
            String t = request.getParameter("tablename");
            String path  = "" + Paths.get(System.getProperty("user.home"), "Downloads") + "";
        	Class.forName("com.mysql.jdbc.Driver");
        	Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/tesseractocr", "root", "");
            Statement stmt = connection.createStatement();
            ResultSet resultSet = stmt.executeQuery("select * from " + t);
            
            XSSFWorkbook workbook = new XSSFWorkbook(); 
            XSSFSheet spreadsheet = workbook.createSheet("question db");
            
            XSSFRow row = spreadsheet.createRow(1);
            XSSFCell cell;
            cell = row.createCell(1);
            cell.setCellValue("qid");
            cell = row.createCell(2);
            cell.setCellValue("qtype");
            cell = row.createCell(3);
            cell.setCellValue("ques");
            cell = row.createCell(4);
            cell.setCellValue("a");
            cell = row.createCell(5);
            cell.setCellValue("b");
            cell = row.createCell(6);
            cell.setCellValue("c");
            cell = row.createCell(7);
            cell.setCellValue("d");
            cell = row.createCell(8);
            cell.setCellValue("ans");
            cell = row.createCell(9);
            cell.setCellValue("mark");
            
            int i = 2;

            while(resultSet.next()) {
               row = spreadsheet.createRow(i);
               cell = row.createCell(1);
               cell.setCellValue(resultSet.getInt("qid"));
               cell = row.createCell(2);
               cell.setCellValue(resultSet.getString("qtype"));
               cell = row.createCell(3);
               cell.setCellValue(resultSet.getString("ques"));
               cell = row.createCell(4);
               cell.setCellValue(resultSet.getString("a"));
               cell = row.createCell(5);
               cell.setCellValue(resultSet.getString("b"));
               cell = row.createCell(6);
               cell.setCellValue(resultSet.getString("c"));
               cell = row.createCell(7);
               cell.setCellValue(resultSet.getString("d"));
               cell = row.createCell(8);
               cell.setCellValue(resultSet.getString("ans"));
               cell = row.createCell(9);
               cell.setCellValue(resultSet.getString("mark"));
               i++;
            }

            FileOutputStream outp = new FileOutputStream(new File(path + "\\exceldatabase.xlsx"));
            workbook.write(outp);
            outp.close();
            session.setAttribute("download","complete");
            response.sendRedirect("PaperSetter");
            out.close();
            
            }
        }
        catch(Exception e)
        {
        	System.out.println(e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
